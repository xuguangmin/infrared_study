/******************************************************************************

                  版权所有 (C), 2001-2020, 北京飞立信科技股份有限公司

 ******************************************************************************
  文 件 名   : util_queue.c
  版 本 号   : 初稿
  作   者   : 贾延刚
  生成日期   : 2012-10-29
  最近修改   :
  功能描述   : 一个通用的队列，数据成员只有一个void指针。
             在尾部追加，从头部取
             使用时，先定义一个UTIL_QUEUE类型的变量，然后调用函数：util_queue_init，
             对队列初始化后，就可以使用了。
             如果使用util_queue_release清空了队列，需要重新初始化以后才可以使用

  函数列表   :
  修改历史   :

******************************************************************************/

#include <stdlib.h>
#include <string.h>
#include "util_queue.h"


typedef struct queue_node *QUEUE_NODE;
struct queue_node
{
	uint8_t    *data;
	int         data_len;
	int         user_data;
	QUEUE_NODE  next;
};

struct util_queue
{
	QUEUE_NODE   head;
	QUEUE_NODE   tail;

	pthread_mutex_t queue_mutex;
};
typedef struct util_queue UTIL_QUEUE;


static UTIL_QUEUE  g_util_queue;
static util_queue_callback  g_util_queue_callback = NULL;

static QUEUE_NODE make_queue_node()
{
	QUEUE_NODE lp_node = (QUEUE_NODE)malloc(sizeof(struct queue_node));
	if(!lp_node)
		return NULL;

	lp_node->data = 0;
	lp_node->next = NULL;
	return lp_node;
}

static void free_queue_node(QUEUE_NODE lp_node)
{
	free(lp_node);
}

static void insert_queue_node(UTIL_QUEUE *lp_util_queue, QUEUE_NODE lp_node)
{
	lp_node->next = NULL;
	if(!lp_util_queue->head)
	{
		lp_util_queue->head = lp_node;
		lp_util_queue->tail = lp_node;
	}
	else
	{
		lp_util_queue->tail->next = lp_node;
		lp_util_queue->tail       = lp_node;
	}
}

/*
 * 向队列中追加数据
 * 队列将创建一个节点，保存输入的数据，
 * 然后追加新节点到队列的尾部，尾指针移到新追加的节点上
 * 返回值：1 成功，0 失败
 */
static int internal_append_data(UTIL_QUEUE *lp_util_queue, int task, const uint8_t *data, int data_len)
{
	QUEUE_NODE idle_node;
	if(!lp_util_queue)
		return 0;

	idle_node = make_queue_node();
	if(!idle_node)
		return 0;

	idle_node->user_data = task;
	idle_node->data      = NULL;
	idle_node->data_len  = 0;
	if(data && data_len > 0)
	{
		idle_node->data = (uint8_t *)malloc(sizeof(uint8_t) * data_len);
		if(!idle_node->data)
			return 0;

		memcpy(idle_node->data, data, data_len);
		idle_node->data_len  = data_len;
	}

	insert_queue_node(lp_util_queue, idle_node);
	return 1;
}

/*
 * 从队列中取头数据
 * 然后删除头节点，头指针移到下一个节点
 * 返回值：1 取到数据，0 未取到数据
 */
static int internal_get_head_data(UTIL_QUEUE *lp_util_queue)
{
	QUEUE_NODE lp_node;
	if(!lp_util_queue || !lp_util_queue->head)
		return 0;

	lp_node = lp_util_queue->head;
	if(g_util_queue_callback)
	{
		g_util_queue_callback(lp_node->data, lp_node->data_len, lp_node->user_data);
	}

	lp_util_queue->head = lp_util_queue->head->next;
	free_queue_node(lp_node);
	return 1;
}

void internal_util_queue_release(UTIL_QUEUE *lp_util_queue)
{
	if(lp_util_queue)
	{
		QUEUE_NODE tempnode;
		while(lp_util_queue->head)
		{
			tempnode = lp_util_queue->head;
			lp_util_queue->head = lp_util_queue->head->next;

			free_queue_node(tempnode);
		}
		lp_util_queue->head = 0;
		lp_util_queue->tail = 0;
	}
}

int util_queue_append_data(int task, const uint8_t *data, int data_len)
{
	pthread_mutex_lock(&g_util_queue.queue_mutex);
	int result = internal_append_data(&g_util_queue, task, data, data_len);
	pthread_mutex_unlock(&g_util_queue.queue_mutex);
	return result;
}

int util_queue_get_head_data()
{
	int result;
	pthread_mutex_lock(&g_util_queue.queue_mutex);
	result = internal_get_head_data(&g_util_queue);
	pthread_mutex_unlock(&g_util_queue.queue_mutex);
	return result;
}

void util_queue_release()
{
	pthread_mutex_lock(&g_util_queue.queue_mutex);
	internal_util_queue_release(&g_util_queue);
	pthread_mutex_unlock(&g_util_queue.queue_mutex);

	pthread_mutex_destroy(&g_util_queue.queue_mutex);
}
void util_queue_init(util_queue_callback  callback)
{
	g_util_queue_callback = callback;
	g_util_queue.head  = 0;
	g_util_queue.tail  = 0;
	pthread_mutex_init(&g_util_queue.queue_mutex, NULL);
}
