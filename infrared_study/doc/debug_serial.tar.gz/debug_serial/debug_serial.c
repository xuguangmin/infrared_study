#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <errno.h>
#include <sys/ioctl.h>
#include <string.h>


typedef struct FPGA_UART_INIT
{
	int           band_rate;
	unsigned char data_bits;       //5,6,7,8
	unsigned char parity;          // 0--no, 1--odd, 2--even, 3--force parity "1", 4--force parity "0"
	unsigned char stop_bits;       // 1,2
}FPGA_UART_INIT_STRU;

#define FPGA_SERIAL_NAME_SUFFIX    "/dev/FPGA_Jikong"

static int g_serial_handle = -1;

static int debug_serial_modify(int fd, int baud_rate, unsigned char data_bits,
		                               unsigned char parity, unsigned char stop_bits)
{
	FPGA_UART_INIT_STRU uartParam;

	uartParam.band_rate = baud_rate;
	uartParam.data_bits = data_bits;
	uartParam.parity    = parity;
	uartParam.stop_bits = stop_bits;

	if (ioctl(fd, 1, &uartParam) < 0)
	{
		perror("Call cmd IOCPRINT fail\n");
	 	return 0;
	}
	printf("fpga serial %d %d-%d-%d\n", baud_rate, data_bits, parity, stop_bits);
	return 1;
}

static int internal_debug_serial_open(int serial_no)
{
	int fd;
	char serial_name[256];

	sprintf(serial_name, "%s%02d", FPGA_SERIAL_NAME_SUFFIX, serial_no - 1);
	fd = open(serial_name, O_RDWR);
	if(fd < 0)
	{
		perror("Cannot Open Serial Port !\n");
		return -1;
	}
	printf("%s(%d) opened!\n", serial_name, serial_no);
	return fd;
}

int debug_serial_log2(int serial_no, const unsigned char *buffer, int data_len)
{
	if(!buffer || data_len <= 0)
		return 0;

	if(g_serial_handle < 0)
	{
		g_serial_handle = internal_debug_serial_open(serial_no);
		if(g_serial_handle < 0)
			return 0;

		if(!debug_serial_modify(g_serial_handle, 115200, 8, 0, 1))
			return 0;
	}

	return (write(g_serial_handle, buffer, data_len) < 0) ? 0:1;
}  

int debug_serial_log(const unsigned char *buffer, int data_len)
{
	return debug_serial_log2(1, buffer, data_len);

}
int devc_fpga_serial_close(int handle)
{
	return (close(handle) == 0) ? 1:0;
}



