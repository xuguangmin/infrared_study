#ifndef __DEBUG_SERIAL_H__
#define __DEBUG_SERIAL_H__

extern int debug_serial_log(const unsigned char *buffer, int data_len);
extern int debug_serial_log2(int serial_no, const unsigned char *buffer, int data_len);

#endif  /* __DEBUG_SERIAL_H__ */
